package entity;

public enum Result {
    PASSED, FAILED
}
