package entity;

public class ManualTest extends Test {
    public ManualTest (TestLevel level, int instability) {
        super(level, instability);
    }
}
