package entity;

public class AutomatedTest extends Test {
    public AutomatedTest(TestLevel level, int instability) {
        super(level, instability);
    }
}
