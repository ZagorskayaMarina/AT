package worker;

import worker.Engineer;

public class TestEngineer extends Engineer {
}
