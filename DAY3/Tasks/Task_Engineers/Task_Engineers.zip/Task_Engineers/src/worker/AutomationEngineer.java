package worker;

public class AutomationEngineer extends Engineer {

}
