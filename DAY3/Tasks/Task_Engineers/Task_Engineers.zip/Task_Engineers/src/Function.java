public interface Function<Engineer, Result> {
    public Result apply (Engineer engineer);
}
